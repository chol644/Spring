import{_ as e,c,e as r}from"./index-B-RuxrIw.js";const t={};function a(o,n){return r(),c("h1",null,"BoardListPage")}const _=e(t,[["render",a]]);export{_ as default};
