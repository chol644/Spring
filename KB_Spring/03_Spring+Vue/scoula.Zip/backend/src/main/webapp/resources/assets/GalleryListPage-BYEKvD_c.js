import{_ as e,c,o as r}from"./index-B8Pst0dz.js";const t={};function a(n,o){return r(),c("h1",null,"GalleryListPage")}const l=e(t,[["render",a]]);export{l as default};
