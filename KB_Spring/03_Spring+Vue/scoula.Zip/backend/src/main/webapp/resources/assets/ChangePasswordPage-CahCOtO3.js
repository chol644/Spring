import{_ as e,c as a,e as c}from"./index-B-RuxrIw.js";const n={};function r(s,o){return c(),a("h1",null,"ChangePasswordPage")}const _=e(n,[["render",r]]);export{_ as default};
