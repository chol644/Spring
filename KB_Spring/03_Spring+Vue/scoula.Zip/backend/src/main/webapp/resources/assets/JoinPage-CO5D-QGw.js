import{_ as e,c,e as n}from"./index-B-RuxrIw.js";const o={};function r(t,a){return n(),c("h1",null,"JoinPage")}const _=e(o,[["render",r]]);export{_ as default};
