import{_ as e,c,o}from"./index-B8Pst0dz.js";const r={};function n(t,a){return o(),c("h1",null,"ProfilePage")}const _=e(r,[["render",n]]);export{_ as default};
