import{_ as e,c,e as r}from"./index-B-RuxrIw.js";const o={};function n(t,a){return r(),c("h1",null,"ProfilePage")}const _=e(o,[["render",n]]);export{_ as default};
