import{_ as e,c,e as r}from"./index-B-RuxrIw.js";const t={};function a(n,s){return r(),c("h1",null,"TravelListPage")}const _=e(t,[["render",a]]);export{_ as default};
