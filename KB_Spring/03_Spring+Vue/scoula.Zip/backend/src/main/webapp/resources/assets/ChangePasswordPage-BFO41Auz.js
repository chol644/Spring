import{_ as e,c as a,o as c}from"./index-B8Pst0dz.js";const n={};function o(r,s){return c(),a("h1",null,"ChangePasswordPage")}const _=e(n,[["render",o]]);export{_ as default};
