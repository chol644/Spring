import{_ as e,c,o}from"./index-B8Pst0dz.js";const r={};function t(a,n){return o(),c("h1",null,"BoardListPage")}const _=e(r,[["render",t]]);export{_ as default};
