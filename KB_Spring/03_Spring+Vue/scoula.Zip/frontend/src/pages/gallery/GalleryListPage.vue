<script setup></script>

<template>
  <h1>GalleryListPage</h1>
</template>
