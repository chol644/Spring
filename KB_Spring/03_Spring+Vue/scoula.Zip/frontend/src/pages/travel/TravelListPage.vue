<script setup></script>

<template>
  <h1>TravelListPage</h1>
</template>
